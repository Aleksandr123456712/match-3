import pygame
import random
import sys
import math

pygame.init()

WINDOW_WIDTH = 640
WINDOW_HEIGHT = 720
HEADER_HEIGHT = 80
CANDY_SIZE = 80
ROWS = 8
COLS = 8

BG_COLOR = (135, 206, 250)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
DARK_OVERLAY = (0, 0, 0, 150)
RED_OVERLAY = (50, 0, 0, 180)

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("3 в ряд")

try:
    icon = pygame.image.load("images/icon.png")
    pygame.display.set_icon(icon)
except:
    pass

sound_enabled = True
try:
    pygame.mixer.music.load("sound/bg.mp3")
    pygame.mixer.music.set_volume(0.5)
except:
    sound_enabled = False

candy_colors = ["blue", "green", "orange", "red", "pink", "purple", "yellow", "teal"]

class Button:
    def __init__(self, x, y, width, height, text, color, hover_color):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.font = pygame.font.SysFont("Arial", 28, bold=True)

    def draw(self, surface, alpha=255):
        mouse_pos = pygame.mouse.get_pos()
        color = self.hover_color if self.rect.collidepoint(mouse_pos) else self.color

        btn_surf = pygame.Surface((self.rect.width, self.rect.height), pygame.SRCALPHA)
        pygame.draw.rect(btn_surf, (*color, alpha), (0, 0, self.rect.width, self.rect.height), border_radius=10)
        pygame.draw.rect(btn_surf, (*WHITE, alpha), (0, 0, self.rect.width, self.rect.height), 3, border_radius=10)

        text_surf = self.font.render(self.text, True, (*WHITE, alpha))
        text_rect = text_surf.get_rect(center=(self.rect.width // 2, self.rect.height // 2))
        btn_surf.blit(text_surf, text_rect)

        surface.blit(btn_surf, self.rect.topleft)

    def is_clicked(self, event):
        return event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.rect.collidepoint(event.pos)


class Candy:
    def __init__(self, row_num, col_num):
        self.row_num = row_num
        self.col_num = col_num
        self.color = random.choice(candy_colors)
        self.base_image = None
        self.image = None
        self.load_image()
        self.rect = self.image.get_rect()
        self.scale = 1.0
        self.snap()

    def load_image(self):
        try:
            image_name = f"images/qw1_{self.color}.png"
            self.base_image = pygame.image.load(image_name).convert_alpha()
            self.base_image = pygame.transform.smoothscale(self.base_image, (CANDY_SIZE, CANDY_SIZE))
            self.image = self.base_image.copy()
        except:
            self.base_image = pygame.Surface((CANDY_SIZE, CANDY_SIZE), pygame.SRCALPHA)
            self.base_image.fill((*pygame.Color(self.color).rgb, 255))
            self.image = self.base_image.copy()

    def draw(self, surface):
        if self.scale < 1.0:
            new_size = (max(0, int(CANDY_SIZE * self.scale)), max(0, int(CANDY_SIZE * self.scale)))
            if new_size[0] > 0:
                self.image = pygame.transform.smoothscale(self.base_image, new_size)
                self.rect.width, self.rect.height = new_size
                self.rect.centerx = self.col_num * CANDY_SIZE + CANDY_SIZE // 2
                self.rect.centery = self.row_num * CANDY_SIZE + CANDY_SIZE // 2 + HEADER_HEIGHT
            else:
                self.image = None
        else:
            self.image = self.base_image
            self.rect.width, self.rect.height = CANDY_SIZE, CANDY_SIZE

        if self.image:
            surface.blit(self.image, self.rect)

    def snap(self):
        self.rect.x = self.col_num * CANDY_SIZE
        self.rect.y = self.row_num * CANDY_SIZE + HEADER_HEIGHT
        self.scale = 1.0

def create_board():
    board = []
    for r in range(ROWS):
        board.append([])
        for c in range(COLS):
            candy = Candy(r, c)
            while (c >= 2 and board[r][c - 1].color == candy.color and board[r][c - 2].color == candy.color) or \
                    (r >= 2 and board[r - 1][c].color == candy.color and board[r - 2][c].color == candy.color):
                candy.color = random.choice(candy_colors)
                candy.load_image()
            board[r].append(candy)
    return board


def find_matches(board):
    matches = set()
    for r in range(ROWS):
        for c in range(COLS - 2):
            if board[r][c].color == board[r][c + 1].color == board[r][c + 2].color:
                matches.update([board[r][c], board[r][c + 1], board[r][c + 2]])
    for c in range(COLS):
        for r in range(ROWS - 2):
            if board[r][c].color == board[r + 1][c].color == board[r + 2][c].color:
                matches.update([board[r][c], board[r + 1][c], board[r + 2][c]])
    return matches


def has_valid_moves(board):
    for r in range(ROWS):
        for c in range(COLS):
            if c < COLS - 1:
                board[r][c], board[r][c + 1] = board[r][c + 1], board[r][c]
                if find_matches(board):
                    board[r][c], board[r][c + 1] = board[r][c + 1], board[r][c]
                    return True
                board[r][c], board[r][c + 1] = board[r][c + 1], board[r][c]
            if r < ROWS - 1:
                board[r][c], board[r + 1][c] = board[r + 1][c], board[r][c]
                if find_matches(board):
                    board[r][c], board[r + 1][c] = board[r + 1][c], board[r][c]
                    return True
                board[r][c], board[r + 1][c] = board[r + 1][c], board[r][c]
    return False

def get_hint(board):
    for r in range(ROWS):
        for c in range(COLS):
            if c < COLS - 1:
                board[r][c], board[r][c + 1] = board[r][c + 1], board[r][c]
                if find_matches(board):
                    c1, c2 = board[r][c], board[r][c + 1]
                    board[r][c], board[r][c + 1] = board[r][c + 1], board[r][c]  # Возвращаем обратно
                    return c1, c2
                board[r][c], board[r][c + 1] = board[r][c + 1], board[r][c]
            if r < ROWS - 1:
                board[r][c], board[r + 1][c] = board[r + 1][c], board[r][c]
                if find_matches(board):
                    c1, c2 = board[r][c], board[r + 1][c]
                    board[r][c], board[r + 1][c] = board[r + 1][c], board[r][c]  # Возвращаем обратно
                    return c1, c2
                board[r][c], board[r + 1][c] = board[r + 1][c], board[r][c]
    return None, None


def is_adjacent(c1, c2):
    return (abs(c1.row_num - c2.row_num) + abs(c1.col_num - c2.col_num)) == 1


def draw_gear(surface, x, y, radius=15, teeth=8):
    color = WHITE
    points = []
    for i in range(teeth * 2):
        angle = math.radians(i * 360 / (teeth * 2))
        r = radius if i % 2 == 0 else radius - 5
        points.append((x + r * math.cos(angle), y + r * math.sin(angle)))
    pygame.draw.polygon(surface, color, points)
    pygame.draw.circle(surface, (50, 50, 50), (x, y), 5)


STATE_MENU = "menu"
STATE_SETTINGS = "settings"
STATE_PLAYING = "playing"
STATE_INGAME_MENU = "ingame_menu"
STATE_GAME_OVER = "game_over"

ANIM_IDLE = "idle"
ANIM_SWAP = "swap"
ANIM_SWAP_BACK = "swap_back"
ANIM_REMOVE = "remove"
ANIM_FALL = "fall"

game_state = STATE_MENU
from_ingame_menu = False

board = create_board()
score = 0
moves = 0
selected_candy = None

anim_state = ANIM_IDLE
anim_candy1 = None
anim_candy2 = None
anim_start_pos1 = (0, 0)
anim_start_pos2 = (0, 0)
anim_end_pos1 = (0, 0)
anim_end_pos2 = (0, 0)
anim_matches = set()
anim_falling_candies = []

go_timer = 0
go_phase = 0
go_overlay_alpha = 0

SWAP_SPEED = 15
REMOVE_SPEED = 0.08
FALL_SPEED = 18

# --- ПОДСКАЗКА (ПЕРЕМЕННЫЕ) ---
HINT_DELAY_MS = 10000  # 10 секунд бездействия
last_action_time = pygame.time.get_ticks()
showing_hint = False
hint_candy1 = None
hint_candy2 = None

# --- КНОПКИ ---
btn_start = Button(WINDOW_WIDTH // 2 - 120, 300, 240, 60, "Начать игру", (46, 139, 87), (60, 179, 113))
btn_settings_menu = Button(WINDOW_WIDTH // 2 - 120, 390, 240, 60, "Настройки", (150, 100, 50), (180, 130, 70))

btn_vol_up = Button(WINDOW_WIDTH // 2 - 120, 300, 240, 60, "Звук +", (70, 130, 180), (100, 149, 237))
btn_vol_down = Button(WINDOW_WIDTH // 2 - 120, 380, 240, 60, "Звук -", (70, 130, 180), (100, 149, 237))
btn_mute = Button(WINDOW_WIDTH // 2 - 120, 460, 240, 60, "Без звука", (180, 50, 50), (220, 80, 80))
btn_back_settings = Button(WINDOW_WIDTH // 2 - 120, 540, 240, 60, "Назад", (100, 100, 100), (140, 140, 140))

btn_restart = Button(WINDOW_WIDTH // 2 - 120, 280, 240, 60, "Начать заново", (46, 139, 87), (60, 179, 113))
btn_sound_ingame = Button(WINDOW_WIDTH // 2 - 120, 360, 240, 60, "Настройки звука", (70, 130, 180), (100, 149, 237))
btn_quit_game = Button(WINDOW_WIDTH // 2 - 120, 440, 240, 60, "Выйти из игры", (180, 50, 50), (220, 80, 80))
btn_close_pause = Button(WINDOW_WIDTH // 2 - 120, 520, 240, 60, "Продолжить", (100, 100, 100), (140, 140, 140))

btn_go_restart = Button(WINDOW_WIDTH // 2 - 120, 400, 240, 60, "Попробовать снова", (46, 139, 87), (60, 179, 113))
btn_go_menu = Button(WINDOW_WIDTH // 2 - 120, 480, 240, 60, "В главное меню", (100, 100, 100), (140, 140, 140))

gear_rect = pygame.Rect(10, 10, 60, 60)

clock = pygame.time.Clock()
running = True

while running:

    if game_state == STATE_PLAYING and anim_state == ANIM_IDLE:
        if pygame.time.get_ticks() - last_action_time >= HINT_DELAY_MS:
            if not showing_hint:
                hint_candy1, hint_candy2 = get_hint(board)
                showing_hint = True

    screen.fill(BG_COLOR)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if game_state == STATE_MENU:
            if btn_start.is_clicked(event):
                board = create_board()
                score, moves = 0, 0
                selected_candy = None
                anim_state = ANIM_IDLE
                # --- ПОДСКАЗКА: Сброс при новой игре ---
                last_action_time = pygame.time.get_ticks()
                showing_hint = False
                game_state = STATE_PLAYING
                if sound_enabled: pygame.mixer.music.play(-1)
            elif btn_settings_menu.is_clicked(event):
                from_ingame_menu = False
                game_state = STATE_SETTINGS

        elif game_state == STATE_SETTINGS:
            if btn_vol_up.is_clicked(event):
                pygame.mixer.music.set_volume(min(1.0, pygame.mixer.music.get_volume() + 0.1))
                sound_enabled = True
            elif btn_vol_down.is_clicked(event):
                vol = max(0.0, pygame.mixer.music.get_volume() - 0.1)
                pygame.mixer.music.set_volume(vol)
                if vol == 0.0: sound_enabled = False
            elif btn_mute.is_clicked(event):
                pygame.mixer.music.set_volume(0.0)
                sound_enabled = False
            elif btn_back_settings.is_clicked(event):
                game_state = STATE_INGAME_MENU if from_ingame_menu else STATE_MENU

        elif game_state == STATE_PLAYING:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # --- ПОДСКАЗКА: Сброс таймера и скрытие при ЛЮБОМ клике ---
                last_action_time = pygame.time.get_ticks()
                showing_hint = False

                if gear_rect.collidepoint(event.pos):
                    game_state = STATE_INGAME_MENU
                elif anim_state == ANIM_IDLE:
                    mx, my = event.pos
                    if my > HEADER_HEIGHT:
                        col = mx // CANDY_SIZE
                        row = (my - HEADER_HEIGHT) // CANDY_SIZE
                        if 0 <= row < ROWS and 0 <= col < COLS:
                            clicked_candy = board[row][col]
                            if selected_candy is None:
                                selected_candy = clicked_candy
                            else:
                                if is_adjacent(selected_candy, clicked_candy):
                                    anim_candy1 = selected_candy
                                    anim_candy2 = clicked_candy
                                    anim_start_pos1 = anim_candy1.rect.topleft
                                    anim_start_pos2 = anim_candy2.rect.topleft
                                    anim_end_pos1 = anim_candy2.rect.topleft
                                    anim_end_pos2 = anim_candy1.rect.topleft
                                    anim_state = ANIM_SWAP
                                    selected_candy = None
                                else:
                                    selected_candy = clicked_candy

        elif game_state == STATE_INGAME_MENU:
            if btn_restart.is_clicked(event):
                board = create_board()
                score, moves = 0, 0
                selected_candy = None
                anim_state = ANIM_IDLE
                last_action_time = pygame.time.get_ticks()
                showing_hint = False
                game_state = STATE_PLAYING
            elif btn_sound_ingame.is_clicked(event):
                from_ingame_menu = True
                game_state = STATE_SETTINGS
            elif btn_quit_game.is_clicked(event):
                pygame.mixer.music.stop()
                game_state = STATE_MENU
            elif btn_close_pause.is_clicked(event):
                game_state = STATE_PLAYING

        elif game_state == STATE_GAME_OVER:
            if go_phase == 1:
                if btn_go_restart.is_clicked(event):
                    board = create_board()
                    score, moves = 0, 0
                    selected_candy = None
                    anim_state = ANIM_IDLE
                    go_timer, go_phase, go_overlay_alpha = 0, 0, 0
                    last_action_time = pygame.time.get_ticks()
                    showing_hint = False
                    game_state = STATE_PLAYING
                elif btn_go_menu.is_clicked(event):
                    pygame.mixer.music.stop()
                    go_timer, go_phase, go_overlay_alpha = 0, 0, 0
                    game_state = STATE_MENU

    if game_state == STATE_PLAYING:
        if anim_state == ANIM_SWAP:
            dx = anim_end_pos1[0] - anim_candy1.rect.x
            dy = anim_end_pos1[1] - anim_candy1.rect.y
            dist = max(abs(dx), abs(dy))

            if dist <= SWAP_SPEED:
                r1, c1 = anim_candy1.row_num, anim_candy1.col_num
                r2, c2 = anim_candy2.row_num, anim_candy2.col_num
                board[r1][c1], board[r2][c2] = board[r2][c2], board[r1][c1]
                anim_candy1.row_num, anim_candy1.col_num = r2, c2
                anim_candy2.row_num, anim_candy2.col_num = r1, c1
                anim_candy1.snap()
                anim_candy2.snap()

                matches = find_matches(board)
                if matches:
                    moves += 1
                    anim_matches = matches
                    anim_state = ANIM_REMOVE
                else:
                    board[r1][c1], board[r2][c2] = board[r2][c2], board[r1][c1]
                    anim_candy1.row_num, anim_candy1.col_num = r1, c1
                    anim_candy2.row_num, anim_candy2.col_num = r2, c2
                    anim_candy1.snap()
                    anim_candy2.snap()

                    anim_start_pos1 = anim_candy1.rect.topleft
                    anim_start_pos2 = anim_candy2.rect.topleft
                    anim_end_pos1 = anim_candy2.rect.topleft
                    anim_end_pos2 = anim_candy1.rect.topleft
                    anim_state = ANIM_SWAP_BACK
            else:
                step_x = (SWAP_SPEED * dx) // dist
                step_y = (SWAP_SPEED * dy) // dist
                anim_candy1.rect.x += step_x
                anim_candy1.rect.y += step_y
                anim_candy2.rect.x -= step_x
                anim_candy2.rect.y -= step_y

        elif anim_state == ANIM_SWAP_BACK:
            dx = anim_end_pos1[0] - anim_candy1.rect.x
            dy = anim_end_pos1[1] - anim_candy1.rect.y
            dist = max(abs(dx), abs(dy))

            if dist <= SWAP_SPEED:
                anim_candy1.snap()
                anim_candy2.snap()
                anim_state = ANIM_IDLE
            else:
                step_x = (SWAP_SPEED * dx) // dist
                step_y = (SWAP_SPEED * dy) // dist
                anim_candy1.rect.x += step_x
                anim_candy1.rect.y += step_y
                anim_candy2.rect.x -= step_x
                anim_candy2.rect.y -= step_y

        elif anim_state == ANIM_REMOVE:
            all_removed = True
            for candy in anim_matches:
                candy.scale -= REMOVE_SPEED
                if candy.scale > 0.1: all_removed = False

            if all_removed:
                score += len(anim_matches) * 10
                for candy in anim_matches:
                    board[candy.row_num][candy.col_num] = None

                anim_falling_candies = []
                for c in range(COLS):
                    empty_spaces = 0
                    for r in range(ROWS - 1, -1, -1):
                        if board[r][c] is None:
                            empty_spaces += 1
                        elif empty_spaces > 0:
                            target_r = r + empty_spaces
                            candy = board[r][c]
                            board[target_r][c] = candy
                            board[r][c] = None
                            candy.row_num = target_r
                            anim_falling_candies.append(candy)

                    for i in range(empty_spaces):
                        r = empty_spaces - 1 - i
                        new_candy = Candy(r, c)
                        new_candy.rect.y = HEADER_HEIGHT - (i + 1) * CANDY_SIZE
                        board[r][c] = new_candy
                        anim_falling_candies.append(new_candy)

                anim_state = ANIM_FALL

        elif anim_state == ANIM_FALL:
            all_landed = True
            for candy in anim_falling_candies:
                target_y = candy.row_num * CANDY_SIZE + HEADER_HEIGHT
                if candy.rect.y < target_y:
                    candy.rect.y += FALL_SPEED
                    if candy.rect.y > target_y: candy.rect.y = target_y
                    all_landed = False

            if all_landed:
                for candy in anim_falling_candies:
                    candy.snap()
                new_matches = find_matches(board)
                if new_matches:
                    anim_matches = new_matches
                    anim_state = ANIM_REMOVE
                else:
                    if not has_valid_moves(board):
                        game_state = STATE_GAME_OVER
                        go_timer, go_phase, go_overlay_alpha = 0, 0, 0
                    else:

                        last_action_time = pygame.time.get_ticks()
                        showing_hint = False
                        anim_state = ANIM_IDLE

    elif game_state == STATE_GAME_OVER:
        go_timer += 1
        if go_phase == 0:
            for r in range(ROWS):
                for c in range(COLS):
                    if board[r][c]:
                        board[r][c].scale -= 0.025
            if go_timer > 60:
                go_phase = 1
        elif go_phase == 1:
            if go_overlay_alpha < 180:
                go_overlay_alpha += 5

    # --- ОТРИСОВКА ---
    if game_state == STATE_MENU:
        font_title = pygame.font.SysFont("Arial", 64, bold=True)
        title = font_title.render("3 В РЯД", True, WHITE)
        title_shadow = font_title.render("3 В РЯД", True, BLACK)
        screen.blit(title_shadow, (WINDOW_WIDTH // 2 - title.get_width() // 2 + 3, 153))
        screen.blit(title, (WINDOW_WIDTH // 2 - title.get_width() // 2, 150))
        btn_start.draw(screen)
        btn_settings_menu.draw(screen)

    elif game_state == STATE_SETTINGS:
        font_title = pygame.font.SysFont("Arial", 48, bold=True)
        title = font_title.render("НАСТРОЙКИ ЗВУКА", True, WHITE)
        screen.blit(title, (WINDOW_WIDTH // 2 - title.get_width() // 2, 200))
        btn_vol_up.draw(screen)
        btn_vol_down.draw(screen)
        btn_mute.draw(screen)
        btn_back_settings.draw(screen)

    elif game_state in (STATE_PLAYING, STATE_INGAME_MENU, STATE_GAME_OVER):
        pygame.draw.rect(screen, (50, 50, 50), (0, 0, WINDOW_WIDTH, HEADER_HEIGHT))
        draw_gear(screen, gear_rect.centerx, gear_rect.centery, 18, 8)

        font_ui = pygame.font.SysFont("Arial", 32, bold=True)
        screen.blit(font_ui.render(f"Счет: {score}", True, WHITE), (90, 20))
        moves_text = font_ui.render(f"Ходы: {moves}", True, WHITE)
        screen.blit(moves_text, (WINDOW_WIDTH - moves_text.get_width() - 20, 20))

        for r in range(ROWS):
            for c in range(COLS):
                rect = pygame.Rect(c * CANDY_SIZE, r * CANDY_SIZE + HEADER_HEIGHT, CANDY_SIZE, CANDY_SIZE)
                pygame.draw.rect(screen, (255, 255, 255, 100), rect)
                pygame.draw.rect(screen, GRAY, rect, 1)

                if anim_state == ANIM_IDLE and board[r][c] == selected_candy:
                    pygame.draw.rect(screen, (255, 255, 0), rect, 4)

        for r in range(ROWS):
            for c in range(COLS):
                if board[r][c]: board[r][c].draw(screen)

        # --- ПОДСКАЗКА: ОТРИСОВКА ПУЛЬСИРУЮЩЕЙ РАМКИ ---
        if showing_hint and game_state == STATE_PLAYING:
            # Пульсация достигается с помощью синуса, зависит от текущего времени
            pulse_alpha = int(abs(math.sin(pygame.time.get_ticks() * 0.005)) * 255)
            hint_surf = pygame.Surface((CANDY_SIZE, CANDY_SIZE), pygame.SRCALPHA)

            if hint_candy1:
                pygame.draw.rect(hint_surf, (255, 255, 0, pulse_alpha), (0, 0, CANDY_SIZE, CANDY_SIZE), 6,
                                 border_radius=10)
                screen.blit(hint_surf, hint_candy1.rect.topleft)
            if hint_candy2:
                pygame.draw.rect(hint_surf, (255, 255, 0, pulse_alpha), (0, 0, CANDY_SIZE, CANDY_SIZE), 6,
                                 border_radius=10)
                screen.blit(hint_surf, hint_candy2.rect.topleft)

        if game_state == STATE_INGAME_MENU:
            overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
            overlay.fill(DARK_OVERLAY)
            screen.blit(overlay, (0, 0))

            font_pause = pygame.font.SysFont("Arial", 48, bold=True)
            pause_text = font_pause.render("ПАУЗА", True, WHITE)
            screen.blit(pause_text, (WINDOW_WIDTH // 2 - pause_text.get_width() // 2, 200))

            btn_restart.draw(screen)
            btn_sound_ingame.draw(screen)
            btn_quit_game.draw(screen)
            btn_close_pause.draw(screen)

        elif game_state == STATE_GAME_OVER:
            if go_phase == 1:
                overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
                overlay.fill((50, 0, 0, go_overlay_alpha))
                screen.blit(overlay, (0, 0))

                text_alpha = min(255, go_overlay_alpha * 2)
                font_go = pygame.font.SysFont("Arial", 64, bold=True)

                text_surf = font_go.render("ХОДОВ НЕТ!", True, WHITE)
                text_surf.set_alpha(text_alpha)
                screen.blit(text_surf, (WINDOW_WIDTH // 2 - text_surf.get_width() // 2, 280))

                if go_overlay_alpha >= 180:
                    btn_go_restart.draw(screen)
                    btn_go_menu.draw(screen)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()